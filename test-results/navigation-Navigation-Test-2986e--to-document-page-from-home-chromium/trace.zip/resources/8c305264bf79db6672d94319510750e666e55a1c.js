(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_recharts_es6_7a9de48b._.js",
  "static/chunks/node_modules_1a693d5f._.js",
  "static/chunks/_8e0e12c5._.js"
],
    source: "dynamic"
});
