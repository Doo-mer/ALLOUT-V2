(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_f7074d7f._.css",
  "static/chunks/node_modules_jotai_esm_6c5130b6._.js"
],
    source: "dynamic"
});
