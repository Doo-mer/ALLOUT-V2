(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/shared/layout/App.tsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/shared_layout_App_tsx_1afe75a0._.js",
  "static/chunks/shared_layout_App_tsx_057364b8._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/shared/layout/App.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);