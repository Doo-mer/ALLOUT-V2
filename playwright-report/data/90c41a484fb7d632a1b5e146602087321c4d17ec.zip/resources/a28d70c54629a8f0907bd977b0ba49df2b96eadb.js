(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/shared_layout_App_tsx_f577e17e._.js",
  "static/chunks/_b8d5973e._.js"
],
    source: "dynamic"
});
