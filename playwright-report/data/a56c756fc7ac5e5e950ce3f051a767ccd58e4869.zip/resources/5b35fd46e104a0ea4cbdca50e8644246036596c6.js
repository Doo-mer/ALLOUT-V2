(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_46d16782._.js",
  "static/chunks/_4d9bf4ff._.js"
],
    source: "dynamic"
});
